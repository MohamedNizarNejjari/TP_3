import java.util.HashSet;
import java.util.Set;

public class Graph {
    private Set<Vertex> vertices;
    private Set<Edge> edges;

    public Graph() {
        vertices = new HashSet<>();
        edges = new HashSet<>();
    }

    public void addVertex(Vertex vertex) {
        vertices.add(vertex);
    }

    public void addEdge(Edge edge) {
        vertices.add(edge.getVertex1());
        vertices.add(edge.getVertex2());
        edges.add(edge);
    }


    public void displayGraph() {
        System.out.println("Vertices: " + vertices);
        System.out.println("Edges: " + edges);
    }
}

