public class Main {
    public static void main(String[] args) {
        Vertex A = new Vertex("A");
        Vertex B = new Vertex("B");
        Vertex C = new Vertex("C");
        Vertex D = new Vertex("D");

        Edge e1 = new Edge(A, B);
        Edge e2 = new Edge(A, C);
        Edge e3 = new Edge(B, C);
        Edge e4 = new Edge(B, D);

        Graph graph = new Graph();
        graph.addEdge(e1);
        graph.addEdge(e2);
        graph.addEdge(e3);
        graph.addEdge(e4);

        graph.displayGraph();
    }
}
